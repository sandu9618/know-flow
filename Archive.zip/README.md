# KnowFlow

KnowFlow is an AI-powered knowledge assistant for teams. Users upload internal documents (policies, specs, meeting notes) to cloud storage; the system indexes them incrementally and provides semantic search and cited Q&A — without loading the entire document corpus into memory at query time.

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React (Vite) |
| API | Node.js (Express or Fastify) |
| Workers | Python (FastAPI) — parsing, embeddings |
| Database | MongoDB (metadata, chunks, vectors, logs) |
| File storage | Cloud object storage (S3 / GCS / R2) |
| LLM | Google Gemini API |

## Documentation

| Document | Description |
|----------|-------------|
| [REQUIREMENTS.md](./REQUIREMENTS.md) | Product vision, user flows, functional and non-functional requirements |
| [ARCHITECTURE.md](./ARCHITECTURE.md) | System design, data flows, monorepo layout, ingestion and query patterns |
| [ROADMAP.md](./ROADMAP.md) | 12-week incremental build plan with deliverables and article mapping |

## Development Approach

Implementation follows the 12-week roadmap in [ROADMAP.md](./ROADMAP.md). Each weekly milestone should be tagged in git (e.g. `week-01-prompts`, `week-03-rag`) so articles and demos can link to the exact code state for that week.

## Status

Requirements and architecture documented. Application code not yet started — Week 1 begins with the prompt template library.
