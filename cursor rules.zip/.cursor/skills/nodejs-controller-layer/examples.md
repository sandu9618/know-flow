# Controller Layer Examples

## Route → controller wiring

```typescript
// routes/documents.routes.ts
import { Router } from 'express';
import { validate } from '../middleware/validate';
import { uploadLimiter } from '../middleware/rateLimit';
import * as documentsController from '../controllers/documents.controller';
import { createDocumentSchema } from '../schemas/documents.schema';

const router = Router();

router.get('/', documentsController.listDocuments);
router.get('/:id', documentsController.getDocument);
router.post(
  '/',
  uploadLimiter,
  validate(createDocumentSchema),
  documentsController.createDocument
);

export default router;
```

## Thin controller + service

```typescript
// controllers/documents.controller.ts
import { Request, Response, NextFunction } from 'express';
import * as documentService from '../services/documents.service';

export async function createDocument(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const result = await documentService.uploadAndEnqueue({
      file: req.file,
      userId: req.user!.id,
    });
    res.status(202).json({ data: result });
  } catch (error) {
    next(error);
  }
}
```

```typescript
// services/documents.service.ts
import { bucketClient } from '../clients/bucket';
import { documentRepository } from '../repositories/documents.repository';
import { ingestionQueue } from '../queues/ingestion.queue';
import { AppError } from '../errors/AppError';

export async function uploadAndEnqueue(input: {
  file: Express.Multer.File;
  userId: string;
}) {
  if (!input.file) {
    throw new AppError('FILE_REQUIRED', 'No file uploaded', 400);
  }

  const storageKey = await bucketClient.upload(input.file);
  const document = await documentRepository.create({
    storageKey,
    userId: input.userId,
    status: 'pending',
  });
  await ingestionQueue.add('ingest', { documentId: document.id });

  return { documentId: document.id, status: document.status };
}
```

## AppError + centralized error handler

```typescript
// errors/AppError.ts
export class AppError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode: number = 500,
    public readonly details?: unknown
  ) {
    super(message);
    this.name = 'AppError';
  }
}
```

```typescript
// middleware/errorHandler.ts
import { Request, Response, NextFunction } from 'express';
import { AppError } from '../errors/AppError';
import { logger } from '../lib/logger';

export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  if (err instanceof AppError) {
    res.status(err.statusCode).json({
      error: { code: err.code, message: err.message, details: err.details },
    });
    return;
  }

  logger.error({ err }, 'Unhandled error');
  res.status(500).json({
    error: { code: 'INTERNAL_ERROR', message: 'Something went wrong' },
  });
}
```

## asyncHandler wrapper (optional)

```typescript
// lib/asyncHandler.ts
import { Request, Response, NextFunction, RequestHandler } from 'express';

export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<void>): RequestHandler =>
  (req, res, next) => {
    fn(req, res, next).catch(next);
  };

// Usage
router.get('/:id', asyncHandler(documentsController.getDocument));
```

## Streaming chat controller

```typescript
// controllers/chat.controller.ts
export async function streamChat(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.flushHeaders();

    const stream = await chatService.createAnswerStream({
      question: req.body.question,
      conversationId: req.body.conversationId,
      userId: req.user!.id,
    });

    req.on('close', () => stream.destroy());

    for await (const chunk of stream) {
      res.write(`data: ${JSON.stringify(chunk)}\n\n`);
    }
    res.end();
  } catch (error) {
    next(error);
  }
}
```

## Bad vs good

**Bad — fat controller:**

```typescript
export async function createDocument(req, res) {
  const file = req.file;
  const key = `docs/${Date.now()}-${file.originalname}`;
  await s3.upload({ Bucket: 'knowflow', Key: key, Body: file.buffer });
  const doc = await Document.create({ key, status: 'pending' });
  await queue.add('ingest', { id: doc._id });
  res.json(doc);
}
```

**Good — thin controller:**

```typescript
export async function createDocument(req, res, next) {
  try {
    const data = await documentService.uploadAndEnqueue({
      file: req.file,
      userId: req.user.id,
    });
    res.status(202).json({ data });
  } catch (error) {
    next(error);
  }
}
```
