---
name: nodejs-controller-layer
description: Guides Express controller design — thin HTTP handlers, service delegation, validation, error handling, and consistent responses. Use when creating or reviewing controllers, routes, or HTTP handlers in apps/api or any Express Node.js API.
---

# Node.js Controller Layer (Express)

## Core rule

Controllers translate HTTP ↔ application calls. They do **not** contain business logic, database queries, or external API calls.

```
Route → Middleware (auth, validate, rate-limit) → Controller → Service → Repository/Client
                                                              ↓
                                                    Error middleware
```

## Controller responsibilities

| Do in controller | Delegate to service/middleware |
|------------------|-------------------------------|
| Read `req` (params, query, body, user) | Business rules and orchestration |
| Call one service method | MongoDB, bucket, queue, Gemini calls |
| Map result to HTTP status + JSON | Retries, token counting, injection defense |
| Call `next(error)` on failure | Chunking, embedding, agent steps |

## File layout (KnowFlow `apps/api`)

```
src/
├── routes/           # Wire paths + middleware only
├── controllers/      # One file per resource (documents, chat, search)
├── services/         # Business logic
├── middleware/       # validate, auth, rateLimit, errorHandler
└── types/            # Request/response DTOs
```

- **Routes** register paths and middleware chains; avoid inline handler logic beyond `controller.method`.
- **Controllers** export named handler functions or a class with bound methods — pick one style per project and stay consistent.

## Handler pattern

Every async controller must:

1. Extract and narrow input (types or validated DTO).
2. Call exactly one service (or a clearly named orchestrator).
3. Return a typed response with the correct status code.
4. Forward errors via `next(error)` — never swallow or `res.status(500).json()` inline for unexpected failures.

```typescript
export async function getDocument(
  req: Request<{ id: string }>,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const document = await documentService.getById(req.params.id);
    res.status(200).json({ data: document });
  } catch (error) {
    next(error);
  }
}
```

Prefer `asyncHandler` wrapper or Express 5 native async support to avoid repetitive try/catch when the project adopts it.

## Validation

Validate **before** the controller runs:

- Use middleware (`validate(schema)`) on the route.
- Controllers assume input is already valid and typed.
- Return `400` with field-level errors from the validator — not from the controller.

## Response shape

Use a consistent envelope across the API:

```typescript
// Success
{ data: T }
{ data: T[], meta: { page, limit, total } }

// Client error (from AppError or validator)
{ error: { code: string, message: string, details?: unknown } }
```

| Situation | Status |
|-----------|--------|
| Created | `201` |
| No content (delete) | `204` |
| Not found | `404` |
| Validation failed | `400` |
| Unauthorized / forbidden | `401` / `403` |
| Conflict (duplicate) | `409` |
| Rate limited | `429` |
| Unexpected server error | `500` (via error middleware only) |

Never leak stack traces or internal messages in production responses.

## Error handling

- Services throw `AppError` (or similar) with `statusCode` and `code`.
- Controllers only call `next(error)`.
- A single `errorHandler` middleware maps errors to the response envelope and logs server errors.

Do not catch errors in controllers only to rethrow generic messages — preserve the original error for the handler.

## Naming conventions

| Artifact | Convention | Example |
|----------|--------------|---------|
| Controller file | `{resource}.controller.ts` | `documents.controller.ts` |
| Handler | verb + resource | `uploadDocument`, `searchDocuments` |
| Route file | `{resource}.routes.ts` | `documents.routes.ts` |
| Service | `{resource}.service.ts` | `documents.service.ts` |

REST mapping: `GET /documents` → `listDocuments`, `GET /documents/:id` → `getDocument`, `POST /documents` → `createDocument`.

## Streaming and long-running work

- **Chat/RAG streaming**: controller sets SSE/stream headers, delegates stream creation to service, pipes `service.stream` to `res`; handle client disconnect (`req.on('close')`).
- **Heavy ingestion**: controller enqueues a job and returns `202` with `{ data: { jobId, status: 'pending' } }` — do not block on parsing or embedding.

## Security and cross-cutting concerns

Keep these in middleware, not controllers:

- Rate limiting (`/chat`, `/upload`)
- Token/cost logging on LLM calls
- Prompt injection sanitization
- File size and MIME checks on upload
- Authentication / authorization

Controllers may read `req.user` set by auth middleware but must not implement auth logic.

## Anti-patterns

- Database or `fetch` calls inside controller handlers
- Multiple unrelated service calls with branching business rules
- Different JSON shapes per endpoint
- `console.log` for request logging — use structured logger in middleware
- Sending response after `next(error)` or calling `res.json` twice
- `any` for `req.body` when a schema exists

## Review checklist

When creating or reviewing controllers:

- [ ] Handler is thin (< ~15 lines); logic lives in service
- [ ] Input validated on route, not in handler
- [ ] Errors passed to `next(error)`
- [ ] Response uses standard `{ data }` / `{ error }` envelope
- [ ] Correct HTTP status for each outcome
- [ ] Async errors handled (wrapper or try/catch)
- [ ] No secrets, raw prompts, or stack traces in responses
- [ ] Streaming/upload endpoints follow non-blocking patterns

## Related skills

- Routes: [nodejs-routes-layer](../nodejs-routes-layer/SKILL.md)
- Services: [nodejs-service-layer](../nodejs-service-layer/SKILL.md)
- Repositories: [nodejs-repository-layer](../nodejs-repository-layer/SKILL.md)

## Examples

See [examples.md](examples.md) for route wiring, controller/service split, and error middleware patterns.
