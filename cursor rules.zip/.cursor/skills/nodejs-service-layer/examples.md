# Service Layer Examples

## CRUD with business rules

```typescript
// services/documents.service.ts
import { documentRepository } from '../repositories/documents.repository';
import { AppError } from '../errors/AppError';
import type { Document } from '../types/document';

export async function getById(id: string): Promise<Document> {
  const document = await documentRepository.findById(id);
  if (!document) {
    throw new AppError('DOCUMENT_NOT_FOUND', 'Document not found', 404);
  }
  return document;
}

export async function deleteDocument(id: string, userId: string): Promise<void> {
  const document = await getById(id);
  if (document.userId !== userId) {
    throw new AppError('FORBIDDEN', 'Not allowed to delete this document', 403);
  }
  if (document.status === 'indexing') {
    throw new AppError('DOCUMENT_BUSY', 'Cannot delete while indexing', 409);
  }
  await documentRepository.softDelete(id);
}
```

```typescript
// repositories/documents.repository.ts
import { DocumentModel } from '../models/document.model';
import type { Document } from '../types/document';

export async function findById(id: string): Promise<Document | null> {
  return DocumentModel.findById(id).lean();
}

export async function softDelete(id: string): Promise<void> {
  await DocumentModel.updateOne({ _id: id }, { deletedAt: new Date() });
}
```

## Upload orchestration (controller stays thin)

```typescript
// services/documents.service.ts
import { bucketClient } from '../clients/bucket.client';
import { documentRepository } from '../repositories/documents.repository';
import { ingestionQueue } from '../queues/ingestion.queue';
import { AppError } from '../errors/AppError';

type UploadInput = {
  file: Express.Multer.File;
  userId: string;
};

type UploadResult = {
  documentId: string;
  status: 'pending';
};

export async function uploadAndEnqueue(input: UploadInput): Promise<UploadResult> {
  if (!input.file?.buffer?.length) {
    throw new AppError('FILE_REQUIRED', 'No file uploaded', 400);
  }

  const storageKey = await bucketClient.upload({
    buffer: input.file.buffer,
    filename: input.file.originalname,
    mimeType: input.file.mimetype,
  });

  const document = await documentRepository.create({
    storageKey,
    userId: input.userId,
    filename: input.file.originalname,
    mimeType: input.file.mimetype,
    sizeBytes: input.file.size,
    status: 'pending',
  });

  try {
    await ingestionQueue.add('ingest', { documentId: document.id });
  } catch {
    await documentRepository.update(document.id, {
      status: 'failed',
      errorMessage: 'Failed to enqueue ingestion job',
    });
    throw new AppError('INGESTION_ENQUEUE_FAILED', 'Could not start processing', 503);
  }

  return { documentId: document.id, status: 'pending' };
}
```

## RAG search service

```typescript
// services/search.service.ts
import { embeddingClient } from '../clients/embedding.client';
import { chunkRepository } from '../repositories/chunks.repository';
import type { SearchResult } from '../types/search';

type SearchInput = {
  query: string;
  limit?: number;
  documentIds?: string[];
};

export async function searchByQuery(input: SearchInput): Promise<SearchResult[]> {
  const limit = Math.min(input.limit ?? 10, 20);
  const queryVector = await embeddingClient.embed(input.query);

  return chunkRepository.vectorSearch({
    vector: queryVector,
    limit,
    filter: input.documentIds ? { documentId: { $in: input.documentIds } } : undefined,
  });
}
```

## Streaming chat service

```typescript
// services/chat.service.ts
import { chunkRepository } from '../repositories/chunks.repository';
import { geminiClient } from '../clients/gemini.client';
import { conversationRepository } from '../repositories/conversations.repository';
import { AppError } from '../errors/AppError';
import type { ChatChunk } from '../types/chat';

type ChatInput = {
  question: string;
  conversationId?: string;
  userId: string;
};

export async function createAnswerStream(input: ChatInput): Promise<AsyncIterable<ChatChunk>> {
  if (!input.question.trim()) {
    throw new AppError('QUESTION_REQUIRED', 'Question cannot be empty', 400);
  }

  const contextChunks = await chunkRepository.vectorSearch({
    query: input.question,
    limit: 8,
  });

  if (input.conversationId) {
    const conversation = await conversationRepository.findById(input.conversationId);
    if (!conversation || conversation.userId !== input.userId) {
      throw new AppError('CONVERSATION_NOT_FOUND', 'Conversation not found', 404);
    }
  }

  return geminiClient.streamAnswer({
    question: input.question,
    context: contextChunks,
    conversationId: input.conversationId,
  });
}
```

## Client with retries (service stays simple)

```typescript
// clients/gemini.client.ts
import { GoogleGenerativeAI } from '@google/generative-ai';
import { withRetry } from '../lib/withRetry';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function embed(text: string): Promise<number[]> {
  return withRetry(async () => {
    const model = genAI.getGenerativeModel({ model: 'text-embedding-004' });
    const result = await model.embedContent(text);
    return result.embedding.values;
  }, { attempts: 3 });
}
```

## Pagination

```typescript
// services/documents.service.ts
type ListInput = { page: number; limit: number; status?: string };
type ListResult = { items: Document[]; total: number };

export async function list(input: ListInput): Promise<ListResult> {
  const limit = Math.min(input.limit, 100);
  const page = Math.max(input.page, 1);
  const skip = (page - 1) * limit;

  const [items, total] = await Promise.all([
    documentRepository.findMany({ status: input.status, skip, limit }),
    documentRepository.count({ status: input.status }),
  ]);

  return { items, total };
}
```

Controller maps to API envelope:

```typescript
const { items, total } = await documentService.list({ page, limit, status });
res.status(200).json({ data: items, meta: { page, limit, total } });
```

## Bad vs good

**Bad — HTTP in service:**

```typescript
export async function getDocument(req: Request, res: Response) {
  const doc = await Document.findById(req.params.id);
  if (!doc) return res.status(404).json({ error: 'Not found' });
  res.json({ data: doc });
}
```

**Good — domain service:**

```typescript
export async function getById(id: string): Promise<Document> {
  const document = await documentRepository.findById(id);
  if (!document) {
    throw new AppError('DOCUMENT_NOT_FOUND', 'Document not found', 404);
  }
  return document;
}
```

**Bad — persistence logic in service:**

```typescript
export async function search(query: string) {
  const embedding = await embed(query);
  return Chunk.aggregate([
    { $vectorSearch: { index: 'chunks', path: 'embedding', queryVector: embedding, limit: 10 } },
    { $project: { text: 1, score: { $meta: 'vectorSearchScore' } } },
  ]);
}
```

**Good — repository owns query:**

```typescript
export async function searchByQuery(input: SearchInput): Promise<SearchResult[]> {
  const vector = await embeddingClient.embed(input.query);
  return chunkRepository.vectorSearch({ vector, limit: input.limit ?? 10 });
}
```

**Bad — silent failure:**

```typescript
export async function getById(id: string) {
  try {
    return await documentRepository.findById(id);
  } catch {
    return null;
  }
}
```

**Good — explicit errors:**

```typescript
export async function getById(id: string): Promise<Document> {
  const document = await documentRepository.findById(id);
  if (!document) {
    throw new AppError('DOCUMENT_NOT_FOUND', 'Document not found', 404);
  }
  return document;
}
```
